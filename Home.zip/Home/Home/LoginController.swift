//
//  LoginController.swift
//  Home
//
//  Created by Lama Alherbish on 1/30/20.
//  Copyright © 2020 Lama Alherbish. All rights reserved.
//

import UIKit

class LoginController:UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
